# 🚀 BÁO CÁO CUỐI KỲ: DỰ ÁN KHỞI NGHIỆP VỚI AI

# Tên Nhóm: F6

**Tên dự án: Mộc Coffee - Cà phê dành cho người trẻ**

# Thanh Vien

[24030271 - Lê Thị Thu Thanh](24030271%20-%20L%C3%AA%20Th%E1%BB%8B%20Thu%20Thanh%203eb4b71209fa80a6a1baca50b0468dca.md)

[24030372 - Nguễn Thị Kim Hương](24030372%20-%20Ngu%E1%BB%85n%20Th%E1%BB%8B%20Kim%20H%C6%B0%C6%A1ng%203eb4b71209fa8062b020fa9ca786d834.md)

[24030084 - Trương Bích Ngọc](24030084%20-%20Tr%C6%B0%C6%A1ng%20B%C3%ADch%20Ng%E1%BB%8Dc%203eb4b71209fa80fd883ef19a97e4e9fe.md)

[24040015 - Nguyễn Công Trình](24040015%20-%20Nguy%E1%BB%85n%20C%C3%B4ng%20Tr%C3%ACnh%203ed4b71209fa8023aac6dae23182686f.md)

[24030072 - Phạm Hoàng Lan Phương](24030072%20-%20Ph%E1%BA%A1m%20Ho%C3%A0ng%20Lan%20Ph%C6%B0%C6%A1ng%203ed4b71209fa80ed87dcc6742063966f.md)

## 0. Tóm tắt dự án

- **Ý tưởng kinh doanh trong 2–3 câu:** Mộc Coffee là mô hình quán cà phê nhỏ tối ưu hóa cho sinh viên và người trẻ, ưu tiên bán mang đi kết hợp không gian chỗ ngồi thoải mái. Quán cung cấp cà phê chất lượng, trà trái cây và bánh ăn nhẹ với mức giá hợp lý, tạo môi trường linh hoạt để học tập, làm việc và gặp gỡ bạn bè.
- **Khách hàng mục tiêu:**  Sinh viên và người trẻ năng động từ 18–30 tuổi có nhu cầu uống cà phê thường xuyên và tìm kiếm không gian học tập, làm việc thoải mái.
- **Vấn đề cần giải quyết:** Khách hàng gặp khó khăn khi phải đánh đổi giữa "giá rẻ", "đồ uống ngon" và "không gian đẹp/yên tĩnh"; nhiều quán lớn giá quá cao, còn quán bình dân lại thiếu không gian học tập chuẩn chỉnh.
- **Sản phẩm / dịch vụ:** Cà phê truyền thống (Đen, Sữa, Bạc xỉu), Cà phê đặc trưng (Cà phê muối, Cà phê dừa), Trà trái cây/Trà sữa, Bánh ăn nhẹ; dịch vụ phục vụ tại quán, bán mang đi và giao hàng qua App.
- **Điểm khác biệt chính:** Phân chia không gian đa chức năng (Khu yên tĩnh học tập, Khu trò chuyện nhóm, Góc check-in chụp ảnh) kết hợp với menu chuẩn vị, giá phù hợp sinh viên và chương trình tích điểm qua mã QR.
- **Doanh thu và lợi nhuận hoạt động dự kiến / tháng (ghi rõ giả định):** 
• Giả định: Phục vụ trung bình 100 đơn/ngày (3.000 đơn/tháng) với giá trung bình 28.000 VNĐ/đơn.   
• Doanh thu dự kiến: 84.000.000 VNĐ/tháng.
• Lợi nhuận hoạt động dự kiến: ~22.000.000 VNĐ/tháng (sau khi trừ chi phí mặt bằng, nguyên liệu, điện nước và chi phí vận hành).
- **Quyết định cuối cùng:** ĐIỀU CHỈNH VÀ TIẾP TỤC.
- **Căn cứ quan trọng nhất cho quyết định:** Nhu cầu tiêu thụ cà phê nội địa tăng trưởng mạnh (USDA dự báo đạt 4,9 triệu bao); mô hình vốn đầu tư ban đầu nhỏ (50–70 triệu VNĐ) giúp giảm rủi ro tài chính và thu hồi vốn nhanh.

## 1. Ý tưởng khởi nghiệp

1. **Mô tả ngắn gọn ý tưởng:** Mộc Coffee là mô hình quán cà phê tinh gọn dành cho người trẻ, giải quyết nhu cầu thưởng thức đồ uống chất lượng với giá túi tiền sinh viên trong một không gian bài trí hiện đại, tối ưu cho học tập và kết nối.  
2. **Nhóm muốn bán sản phẩm hoặc cung cấp dịch vụ gì?**

Đồ uống: Cà phê phin/máy truyền thống (Đen, Sữa, Bạc xỉu), Cà phê sáng tạo (Muối, Dừa), Trà trái cây, Trà sữa và nước giải khát.   

Thực phẩm: Một số loại bánh ngọt/bánh ăn nhẹ kèm theo.   

Dịch vụ: Phục vụ tại quán, bán mang đi (Take-away) và giao hàng tận nơi qua các ứng dụng đặt món (GrabFood, ShopeeFood). 

1. **Vì sao nhóm lựa chọn ý tưởng này?** Cà phê là sản phẩm có tần suất tiêu thụ lặp lại hàng ngày rất cao trong giới trẻ. Đồng thời, mô hình quán quy mô nhỏ có vốn khởi nghiệp vừa phải (50–70 triệu VNĐ), dễ vận hành và thuận tiện quảng bá qua các kênh truyền thông xã hội như TikTok, Facebook và Instagram.
2. **AI đã hỗ trợ phát triển hoặc cải thiện ý tưởng như thế nào?** AI hỗ trợ nhóm đề xuất & phát triển ý tưởng, xác định chân dung khách hàng mục tiêu, gợi ý tên thương hiệu "Mộc Coffee", phân tích thói quen tiêu dùng, ước tính chi phí đầu tư ban đầu, xây dựng chiến lược Marketing trên MXH và định hình các điểm khác biệt cạnh tranh.
3. **Điểm hấp dẫn nhất của ý tưởng là gì? Vì sao?** Mức giá cực kỳ "mềm" chuẩn sinh viên nhưng vẫn mang lại trải nghiệm không gian chỉn chu, có phong cách riêng biệt để khách hàng vừa học tập, làm việc vừa thoải mái gặp gỡ bạn bè.

## 2. Khách hàng mục tiêu và vấn đề

| Nội dung | Câu trả lời của nhóm | Căn cứ / nguồn nếu có |
| --- | --- | --- |
| Khách hàng mục tiêu là ai? | Sinh viên và người trẻ năng động trong độ tuổi từ 18–30, thường xuyên học tập, làm việc hoặc gặp gỡ bạn bè tại quán cà phê. | Khảo sát thực tế hành vi người trẻ đô thị. |
| Đặc điểm chính của khách hàng | Năng động, uống cà phê/trà thường xuyên; ngân sách chi tiêu vừa phải; sử dụng MXH (TikTok, FB, IG) hàng ngày; thích không gian đẹp để chụp ảnh check-in và cần nơi yên tĩnh để học tập/làm việc. | Phân tích hành vi tiêu dùng Gen Z & Millennials. |
| Vấn đề hoặc khó khăn | Cảm thấy các chuỗi quán lớn có giá đắt so với thu nhập; quán rẻ thì hay ồn ào, thiếu ổ cắm; không gian đẹp thì đồ uống dở; buộc phải lựa chọn giữa *giá rẻ – đồ uống ngon – không gian đẹp* | Phỏng vấn sâu 50 sinh viên tại các trường ĐH |
| Vì sao vấn đề đáng giải quyết? | Quán cà phê hiện nay đã trở thành "văn phòng linh hoạt" của giới trẻ; giải quyết được bài toán cân bằng này sẽ giúp quán giữ chân khách hàng lâu dài và tạo dòng tiền ổn định. | Báo cáo thị trường iPOS.vn (Quán cà phê là không gian làm việc thứ 2). |
| Cách khách hàng đang giải quyết vấn đề | Ghé quán bình dân vỉa hè (chấp nhận nóng/ồn); chấp nhận chi tiền cao ở các chuỗi lớn; đặt mang đi qua App hoặc tìm kiếm quán mới dựa trên review TikTok/Google Maps. | Khảo sát thói quen giải quyết vấn đề. |

## 3. Sản phẩm hoặc dịch vụ

- **Mô tả sản phẩm / dịch vụ:** Mộc Coffee cung cấp trải nghiệm F&B toàn diện cho sinh viên với menu đồ uống đa dạng (Cà phê mộc, Cà phê muối/dừa, Trà trái cây), bánh ngọt ăn nhẹ, không gian chỗ ngồi phân khu khoa học và hệ thống gọi món qua mã QR tiện lợi.
- **Vấn đề khách hàng được giải quyết:** Xóa bỏ rào cản tài chính cho sinh viên khi cần tìm một nơi vừa có đồ uống hợp khẩu vị, vừa có chỗ ngồi làm việc/học tập thoải mái mà không lo về giá.
- **Lợi ích khách hàng nhận được:** Đồ uống giá hợp túi tiền; có khu vực yên tĩnh để tập trung làm việc; có không gian riêng để trò chuyện nhóm; có góc check-in sống ảo đẹp và quy trình tích điểm đổi quà thân thiện.
- **Điểm khác biệt chính:** Thiết kế không gian 3 phân khu rõ rệt (*Khu yên tĩnh – Khu trò chuyện – Góc Check-in*), kết hợp hệ thống thẻ thành viên tích điểm điện tử qua QR code ngay tại bàn.
- **Lý do quan trọng nhất khiến khách hàng lựa chọn sản phẩm / dịch vụ:** Mộc Coffee mang lại giá trị vượt trội so với chi phí bỏ ra: "Uống ngon – Giá hợp lý – Chỗ học tập/làm việc thoải mái".

## 4. Nghiên cứu thị trường và kiểm chứng

- **Thị trường nhóm muốn tham gia:** Thị trường Cà phê và F&B tại Việt Nam, tập trung phân khúc quán cà phê quy mô nhỏ (Micro-coffee shop) dành cho người trẻ đô thị.
- **Nhu cầu chính của khách hàng:** [Đồ uống ngon sạch, không gian học tập/làm việc linh hoạt, trải nghiệm công nghệ tiện lợi (QR menu, thanh toán chuyển khoản, tích điểm).
- **Xu hướng quan trọng:** Quán cà phê trở thành "văn phòng linh hoạt"; khách hàng ưu tiên trải nghiệm không gian đa chức năng; ứng dụng công nghệ QR/App trong vận hành; thị trường quy mô lớn nhưng cạnh tranh ngày càng cao.
- **Cơ hội:** Xây dựng mô hình "Quán cà phê thân thiện với sinh viên" linh hoạt, chi phí đầu tư ban đầu thấp, tiếp cận khách hàng nhanh qua TikTok/Reels.
- **Rủi ro / vấn đề thị trường:** Áp lực cạnh tranh gay gắt từ các thương hiệu lớn; chi phí mặt bằng cao; khách hàng trẻ nhạy cảm về giá và thị hiếu thay đổi rất nhanh.

### Kiểm tra ít nhất 2 thông tin quan trọng bằng nguồn ngoài AI

| Thông tin cần kiểm tra | Nguồn, liên kết và ngày truy cập | Nguồn nói gì? | Kết luận của nhóm |
| --- | --- | --- | --- |
| 1. Nhu cầu tiêu thụ cà phê nội địa tại Việt Nam | USDA Foreign Agricultural Service (Báo cáo Ngành Cà phê Việt Nam 2025/2026). | Dự báo tiêu thụ cà phê nội địa Việt Nam đạt khoảng **4,9 triệu bao (loại 60kg)** trong niên vụ 2025/2026, tăng so với 4,8 triệu bao của 2024/25 nhờ văn hóa cà phê và dân số trẻ đô thị. | **Được xác nhận:** Thị trường cà phê nội địa còn rất nhiều dư địa phát triển, nhu cầu uống cà phê hàng ngày của người trẻ là hoàn toàn thực tế |
| 2. Quy mô và xu hướng sử dụng quán cà phê của khách hàng | [iPOS.vn](http://ipos.vn/) – Báo cáo Thị trường F&B Việt Nam (Báo cáo F&B 2024 - Xu hướng 2025). | Toàn quốc có khoảng **329.500 cửa hàng F&B** (2025); người dùng có xu hướng coi quán cà phê là "văn phòng linh hoạt" và chuộng các tiện ích QR Menu, thanh toán hiện đại. | **Được xác nhận:** Cần đẩy mạnh tính năng không gian học tập và ứng dụng công nghệ QR để phù hợp với xu hướng chung của thị trường. |

**Sau nghiên cứu, ý tưởng ban đầu còn đáng để tiếp tục không? Vì sao?** Có tiếp tục. Mặc dù thị trường cạnh tranh cao, nhưng nhu cầu của phân khúc sinh viên luôn ổn định. Việc đi theo mô hình tinh gọn (50-70 triệu VNĐ) giúp Mộc Coffee duy trì điểm hòa vốn thấp và an toàn về mặt tài chính. 

## 5. Phân tích đối thủ cạnh tranh

> Ghi **ít nhất 3 đối thủ phù hợp**. Điểm yếu hoặc khoảng trống là nhận định của nhóm; thêm căn cứ để người đọc kiểm tra.
> 

| Đối thủ | Sản phẩm / dịch vụ | Khách hàng của họ | Điểm mạnh | Điểm yếu / khoảng trống | Dự án của nhóm khác ở đâu? | Nguồn |
| --- | --- | --- | --- | --- | --- | --- |
| Các Chuỗi Lớn (Highlands / The Coffee House) | Cà phê, Trà, Bánh ngọt, Không gian máy lạnh | Nhân viên văn phòng, người có thu nhập trung bình - khá | Thương hiệu mạnh, vị trí đẹp, quy chuẩn dịch vụ tốt | Giá thành cao (45k – 70k/ly), giờ cao điểm rất ồn ào, khó tập trung học tập | Mộc Coffee có giá rẻ hơn 40%, thiết kế riêng khu vực yên tĩnh cho sinh viên học bài | [[URL]](highlandscoffee.com.vn)[highlandscoffee.com.vn](http://highlandscoffee.com.vn/) |
| Quán Cà Phê Cốc / Xe Bán Mang Đi | Cà phê đen, sữa, mang đi nhanh | Người lao động, học sinh, tài xế công nghệ | Giá rất rẻ (15k – 20k), phục vụ cực kỳ nhanh chóng | Không có chỗ ngồi học tập, chất lượng hạt cà phê chưa đồng đều | Mộc Coffee cung cấp chỗ ngồi máy lạnh chỉn chu, nguồn hạt mộc sạch an toàn | Khảo sát thực địa |
| Các Quán Café Chạy Theo Trend | Đồ uống hot-trend, góc sống ảo | Sinh viên, Hot TikToker, giới trẻ thích check-in | Trang trí rất đẹp, dễ thu hút chú ý ban đầu trên MXH | Đồ uống giá cao nhưng chất lượng trung bình; khách chỉ đến 1 lần rồi bỏ | Mộc Coffee tập trung vào chất lượng đồ uống ổn định và trải nghiệm học tập để khách quay lại hàng tuần | Khảo sát MXH |

**Đối thủ tạo áp lực lớn nhất và lý do:** Các quán cà phê nhỏ nằm gần khu vực các trường đại học. Lý do là họ có lợi thế về khoảng cách địa lý và đã có lượng khách quen sinh viên từ trước. 

## 6. Phân tích SWOT

> **S / W:** yếu tố bên trong dự án. **O / T:** yếu tố bên ngoài từ thị trường, khách hàng, công nghệ hoặc cạnh tranh. Viết lý do cụ thể; nếu dùng dữ kiện bên ngoài, dẫn nguồn.
> 

| Yếu tố | Nhận định cụ thể của nhóm | Tác động đến dự án |
| --- | --- | --- |
| **S — Điểm mạnh** | Mức giá cạnh tranh; mô hình không gian phân khu thông minh; ứng dụng QR menu & tích điểm linh hoạt. | Giúp thu hút sinh viên nhanh chóng và tạo sự tiện lợi. |
| **W — Điểm yếu** | Thương hiệu mới chưa có độ nhận diện; diện tích quán quy mô nhỏ giới hạn số chỗ ngồi. | Cần thời gian đầu đẩy mạnh truyền thông để kéo khách. |
| **O — Cơ hội** | Thị trường cà phê đô thị tăng trưởng; thói quen ra quán học tập của sinh viên ngày càng phổ biến | Dễ dàng lấp đầy công suất quán trong các đợt thi học kỳ. |
| **T — Thách thức** | Cạnh tranh gay gắt về giá; chi phí mặt bằng tăng; thị hiếu món mới của sinh viên thay đổi nhanh. | Áp lực phải liên tục cập nhật menu để giữ chân khách. |
- **Điểm mạnh quan trọng nhất và lý do:**  Mức giá hợp lý kết hợp với không gian học tập tiện nghi – đánh đúng "điểm đau" tài chính của sinh viên.
- **Điểm yếu nguy hiểm nhất và lý do:** Nhãn hiệu chưa có độ uy tín ban đầu, dễ bị chìm giữa hàng loạt quán cà phê xung quanh.
- **Cơ hội lớn nhất:** Xu hướng người trẻ coi quán cà phê là không gian làm việc/học tập chính
- **Thách thức lớn nhất:** Sự biến động của chi phí vận hành và rủi ro khách hàng chuyển sang các quán trend mới.
- **Nhóm sẽ phản ứng như thế nào?** Tập trung chạy các chiến dịch TikTok địa phương (Local TikTok Marketing), phát hành thẻ tích điểm sinh viên và giữ chất lượng đồ uống luôn ổn định.

## 7. Năm áp lực cạnh tranh của Porter

> Đánh giá từng yếu tố ở mức **Thấp / Trung bình / Cao**, sau đó giải thích lý do. Không dùng một mức chung cho cả năm yếu tố.
> 

| Áp lực cạnh tranh | Mức độ | Lý do cụ thể |
| --- | --- | --- |
| Cạnh tranh giữa các đối thủ hiện tại | Cao | Ngành F&B có hơn 329.000 cửa hàng, mật độ quán xung quanh khu đại học cực kỳ dày đặc |
| Nguy cơ đối thủ mới gia nhập | Cao | Rào cản gia nhập mô hình quán cà phê nhỏ khá thấp, chi phí mở quán không quá lớn. |
| Quyền thương lượng của nhà cung cấp | Thấp | Nguồn cung ứng hạt cà phê, trà và nguyên liệu F&B tại Việt Nam vô cùng phong phú. |
| Quyền thương lượng của khách hàng | Cao | Sinh viên rất nhạy cảm về giá và dễ dàng chuyển sang quán khác nếu không hài lòn |
| Nguy cơ từ sản phẩm / dịch vụ thay thế | Trung  | Trà sữa, nước ép đóng lon hay tự pha cà phê tại nhà có thể thay thế nhu cầu đồ uống |

**Sau phân tích, thị trường có hấp dẫn để tham gia không? Vì sao?**

Vẫn hấp dẫn. Tuy áp lực cạnh tranh cao nhưng sức mua lớn và dòng tiền quay vòng nhanh. Mô hình nhỏ giúp Mộc Coffee dễ dàng thích ứng và duy trì chi phí cố định ở mức an toàn.

## 8. Điều chỉnh ý tưởng kinh doanh

| Nội dung | Ý tưởng ban đầu | Phát hiện từ thị trường / đối thủ / SWOT / Porter | Phiên bản điều chỉnh |
| --- | --- | --- | --- |
| Vấn đề khách hàng | Chỉ nghĩ khách hàng cần nơi uống cà phê giá rẻ | Khách hàng cần một không gian tích hợp: vừa uống ngon, vừa có góc chụp ảnh và chỗ học yên tĩnh. | Cung cấp giải pháp không gian đa năng kết hợp đồ uống ngon giá sinh viên |
| Sản phẩm / dịch vụ | Bán menu mở rộng nhiều loại đồ uống phức tạp | Menu quá rộng làm tăng chi phí tồn kho nguyên liệu và khó kiểm soát chất lượng. | Tập trung vào Menu tinh gọn (Cà phê cốt lõi, Trà trái cây Hot-trend, Bánh ngọt). |
| Khách hàng mục tiêu | Người trẻ nói chung | Học sinh - Sinh viên khu vực lân cận quán là tập khách hàng có tần suất quay lại cao nhất | Tập trung mũi nhọn vào Sinh viên các trường ĐH/CĐ bán kính 2km |
| Cách cạnh tranh | Chỉ dùng giảm giá đơn thuần. | Giảm giá dễ gây lỗ; khách hàng thích sự tiện lợi và được ghi nhận ưu đãi lâu dài. | Cạnh tranh bằng Trải nghiệm công nghệ (QR Menu), Tích điểm thành viên & Dịch vụ thân thiện. |
- **Vấn đề lớn nhất nhóm phát hiện:**  Khách hàng trẻ rất nhanh chán nếu menu không có món mới và không gian không đáp ứng được nhu cầu học tập.
- **Điểm cần thay đổi nhất trong ý tưởng ban đầu:** Không dàn trải menu mà tập trung tối ưu hóa các món chủ lực (Hero Drinks) và phân khu chỗ ngồi rõ ràng
- **Có cần thay đổi khách hàng mục tiêu không? Vì sao?** Thu hẹp lại chính xác nhóm Sinh viên đại học để các chiến dịch Marketing trên TikTok đi đúng đối tượng
- **Có cần thay đổi cách cạnh tranh không? Vì sao?** 
 Có, chuyển từ đua giá rẻ sang đua về **"Giá trị trải nghiệm / Giá tiền"**
- **Nhóm đồng ý / không đồng ý với đề xuất nào? Vì sao?** *Đồng ý:* Áp dụng QR code gọi món, phân khu không gian và thẻ tích điểm.   *Từ chối:* Mở rộng menu quá nhiều món vì sẽ làm tăng chi phí nguyên liệu và lãng phí.
- **Mô tả ngắn gọn ý tưởng sau điều chỉnh:** [Mộc Coffee là mô hình quán cà phê chuẩn sinh viên với menu tinh gọn, ứng dụng công nghệ gọi món QR, không gian tối ưu cho học tập/sống ảo và mức giá cực kỳ hợp lý.

## 9. Phân tích tài chính dự kiến

**Đơn vị tiền tệ:** VNĐ

**Đơn vị bán:** Đơn hàng / Ly đồ uống

**Kỳ dự báo:** Tháng (Dự báo hoạt động cho 1 tháng vận hành chuẩn)

**Cơ sở ước lượng số lượng bán mỗi tháng:** Giả định quán phục vụ trung bình 100 ly/ngày × 30 ngày = 3.000 ly/tháng (Dựa trên quy mô quán nhỏ 25–35m²). 

### 9.1. Chi phí khởi đầu (chi một lần)

| Khoản chi | Số tiền | Cách ước tính / nguồn | Cần thiết ngay? |
| --- | --- | --- | --- |
| Mua sắm máy pha/xay cà phê & dụng cụ pha chế | 25.000.000 VNĐ | Thiết bị dòng bán chuyên nghiệp cho quán nhỏ | Có |
| Đặt cọc mặt bằng & Trang trí không gian (Decor, Bảng hiệu) | 20.000.000 VNĐ | Chi phí sơn, đèn, bàn ghế đơn giản phong cách Mộc | Có |
| Bàn ghế, Tủ mát, Hệ thống POS/QR tính tiền | 12.000.000 VNĐ | Khảo sát thực tế thiết bị quán nhỏ | Có |
| Nguyên liệu ban đầu & Giấy phép | 3.000.000 VNĐ | Nhập hàng đợt đầu & thủ tục đăng ký | Có |
| **Tổng chi phí khởi đầu** | **[Tổng các khoản trên]** | (Nằm trong khoảng 50 - 70 triệu VNĐ dự kiến) |  |

### 9.2. Giá bán và doanh thu dự kiến mỗi tháng

| Sản phẩm / dịch vụ | Giá bán mỗi đơn vị | Số lượng bán dự kiến / tháng | Doanh thu dự kiến / tháng | Căn cứ cho giá và số lượng |
| --- | --- | --- | --- | --- |
| Cà phê truyền thống (Đen, Sữa, Bạc xỉu) | 22.000 VNĐ | 1.500 ly | 33.000.000 VNĐ | Mức giá phù hợp sinh viên, sản phẩm bán chạy nhất. |
| Cà phê đặc trưng (Cà phê Muối, Cà phê Dừa) | 28.000 VNĐ | 800 ly | 22.400.000 VNĐ | Món đặc trưng thu hút giới trẻ. |
| Trà trái cây, Trà sữa & Bánh ăn nhẹ | 28.000 VNĐ | 700 ly/phần | 19.600.000 VNĐ | Phục vụ nhóm khách không uống cà phê |
| **Tổng** |  | 3.000 đơn | 75.000.000 VNĐ | Cộng doanh thu các dòng |

### 9.3. Chi phí vận hành mỗi tháng

| Khoản chi | Loại chi phí | Cách tính | Số tiền / tháng | Nguồn / giả định |
| --- | --- | --- | --- | --- |
| Giá vốn hàng bán (Hạt cà phê, trà, sữa, ly nhựa, ống hút) | Biến đổi | ~30% Doanh thu | 22.500.000 VNĐ | Ước tính nguyên liệu ngành F&B. |
| Thuê mặt bằng hàng tháng (Quán nhỏ) | Cố định | Mức thuê cố định quán nhỏ | 10.000.000 VNĐ | Khảo sát mặt bằng hẻm lớn/gần trường ĐH |
| Lương nhân viên (2 Part-time sinh viên) | Cố định | Trả theo giờ (20k/h) | 8.000.000 VNĐ | Giờ làm ca linh hoạt |
| Điện, nước, Wi-Fi tốc độ cao | Cố định | Thực tế sử dụng | 3.500.000 VNĐ | Định mức chi phí tiện ích |
| Chi phí Marketing (Ads TikTok, voucher) | Biến đổi | ~5% Doanh thu | 3.750.000 VNĐ | Ngân sách chạy quảng cáo kéo khách |
| **Tổng chi phí biến đổi** |  |  | **26.250.000 VNĐ** |  |
| **Tổng chi phí cố định** |  |  | 21.500.000 VNĐ |  |

### 9.4. Kết quả dự kiến và điểm hòa vốn

> **Hướng dẫn trong Notion:** Các dòng nằm giữa `$$` là mã KaTeX để trình bày công thức. Sau khi nhập Markdown, nếu công thức chưa tự chuyển thành khối phương trình, hãy tạo một dòng mới bằng `/math` → **Block equation**, rồi sao chép **phần giữa hai dấu `$$`** vào khối đó; bỏ hai dòng `$$`. Equation block chỉ **hiển thị công thức**, không tự tính ra kết quả. Nhóm vẫn phải thay số, tính và ghi kết quả bên dưới. Với nhiều sản phẩm, tính doanh thu và chi phí biến đổi riêng cho từng loại rồi cộng lại.
> 

**Doanh thu dự kiến mỗi tháng**

$$
\text{Doanh thu/tháng}=\sum_{i=1}^{n}\bigl(\text{Giá bán}_i\times\text{Số lượng bán}_i\bigr)
$$

Thay số và kết quả: 

$$
\text{Doanh thu/tháng} = (22.000 \times 1.500) + (28.000 \times 800) + (28.000 \times 700) = \mathbf{75.000.000 \text{ VNĐ/tháng}}
$$

**Số dư đảm phí dự kiến mỗi tháng** *(doanh thu trừ toàn bộ chi phí biến đổi; không gọi là “lãi gộp” trong phép tính đơn giản này)*

$$
\text{Số dư đảm phí/tháng}=\text{Doanh thu/tháng}-\text{Chi phí biến đổi/tháng}
$$

Thay số và kết quả:

$$
\text{Số dư đảm phí/tháng} = 75.000.000 - 26.250.000 = \mathbf{48.750.000 \text{ VNĐ/tháng}}
$$

**Lợi nhuận hoạt động dự kiến mỗi tháng**

$$
\text{Lợi nhuận hoạt động/tháng}=\text{Doanh thu/tháng}-\text{Chi phí biến đổi/tháng}-\text{Chi phí cố định/tháng}
$$

Thay số và kết quả: 

$$
\text{Lợi nhuận hoạt động/tháng} = 48.750.000 - 21.500.000 = \mathbf{27.250.000 \text{ VNĐ/tháng}}
$$

**Điểm hòa vốn theo số đơn vị bán mỗi tháng** *(chỉ dùng trực tiếp khi bán một sản phẩm hoặc một gói cố định)*

Tỷ lệ số dư đảm phí (Contribution Margin Ratio - CMR):

$$
\text{CMR} = \frac{\text{Số dư đảm phí}}{\text{Doanh thu}} = \frac{48.750.000}{75.000.000} = 0,65 \quad (65\%)
$$

**Doanh thu hòa vốn mỗi tháng:**

$$
\text{Doanh thu hòa vốn} = \frac{\text{Chi phí cố định}}{\text{CMR}} = \frac{21.500.000}{0,65} \approx \mathbf{33.076.923 \text{ VNĐ/tháng}}
$$

**Số ly đồ uống bán ra để hòa vốn (với giá bán trung bình ~25.000 VNĐ/ly):** 

$$
\text{Số ly hòa vốn/tháng} = \frac{33.076.923}{25.000} \approx \mathbf{1.323 \text{ ly/tháng}} \quad (\approx 44 \text{ ly/ngày})
$$

### 9.5. Kiểm tra giả định và quyết định của nhóm

| Giả định quan trọng | Căn cứ hiện có | Nếu kết quả thấp hơn dự kiến, nhóm sẽ làm gì? |
| --- | --- | --- |
| Số lượng khách mua mỗi tháng (Dự kiến: 3.000 ly/tháng - trung bình 100 ly/ngày) | Dựa trên khảo sát nhu cầu sinh viên và công suất thực tế của các quán cà phê nhỏ diện tích 25-35m² gần các trường ĐH | **1.** Đẩy mạnh khuyến mãi mua 1 tặng 1 / giảm 20% cho sinh viên trong các tuần thi; 
**2.** Đăng ký bán trên các ứng dụng GrabFood, ShopeeFood để tăng lượng đơn bán mang đi; **3.** Đẩy mạnh quay video ngắn TikTok/Reels tiếp cận sinh viên lân cận trong bán kính 2km |
| Giá bán trung bình (25.000 VNĐ/ly) và Chi phí vận hành (Mặt bằng 10 triệu/tháng) | Khảo sát thực tế mặt bằng hẻm lớn gần trường đại học và giá nguyên liệu hạt cà phê mộc từ nhà cung cấp. | **1.** Nếu chi phí nguyên liệu tăng, nhóm sẽ điều chỉnh lại tỷ lệ định lượng nguyên liệu hoặc đàm phán mua hạt cà phê với số lượng lớn hơn để lấy giá sỉ tốt hơn; **2.** Tối ưu lịch ca làm việc của nhân viên part-time để giảm chi phí nhân sự vào các khung giờ vắng khách. |

**Kết quả tài chính có làm nhóm thay đổi ý tưởng hoặc quyết định cuối cùng không? Vì sao?** [Điền nội dung]

**KHÔNG THAY ĐỔI QUYẾT ĐỊNH.**

**Lý do:**

Kết quả tính toán tài chính cho thấy điểm hòa vốn của Mộc Coffee chỉ ở mức

**1.323 ly/tháng (khoảng 44 ly/ngày)**

. Đây là con số rất khả thi và an toàn đối với một quán cà phê nhỏ gần khu vực trường đại học

. Biên lợi nhuận gộp đạt khoảng

**70%**

(chi phí nguyên liệu chiếm ~30%), tạo khoảng trống an toàn đủ lớn để nhóm duy trì hoạt động ngay cả khi doanh thu ban đầu chưa đạt tối đa kỳ vọng

.

## 10. Tài liệu tham khảo

- **USDA Foreign Agricultural Service.** *Coffee: World Markets and Trade - Vietnam Coffee Report 2025/2026*.
    
    URL: [https://www.fas.usda.gov/data/coffee-world-markets-and-trade](https://www.google.com/search?q=https://www.fas.usda.gov/data/coffee-world-markets-and-trade). Truy cập ngày 25/09/2026[cite: 18, 23].
    
- **iPOS.vn.** *Báo cáo Thị trường Kinh doanh F&B tại Việt Nam 2024 - Xu hướng 2025*.
    
    URL: [https://ipos.vn/bao-cao-thi-truong-fnb-viet-nam-2024/](https://www.google.com/search?q=https://ipos.vn/bao-cao-thi-truong-fnb-viet-nam-2024/). Truy cập ngày 28/09/2026[cite: 18, 19, 23].
    
- **Highlands Coffee.** *Menu sản phẩm và Mô hình trải nghiệm khách hàng*.
    
    URL: [https://www.highlandscoffee.com.vn/](https://www.highlandscoffee.com.vn/). Truy cập ngày 20/09/2026